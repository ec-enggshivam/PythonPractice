def sample(m):
  print ('sample started...')
  for i in range(m):
    print ('value of i= ',i)
  print ('end of sample')

print ('main app starts here...')
a=10
b=20
sample(b-a)

for j in range(a,b):
  print ('value of j=',j)

print ('end of the app')


