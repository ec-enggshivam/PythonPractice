

class Person:
    pass



P1=Person()
print(P1)
#L1=list()
#print(L1)

P1.name="Raju"
P1.age=27
print(P1.name)
print(P1.age)





