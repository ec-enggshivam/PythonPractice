'''
try:
    exit()
except:
    print("Caught")

print("Hi Hello World")
'''
try:
    exit()
except Exception:
    print("Caught")

print("Hi Hello World")