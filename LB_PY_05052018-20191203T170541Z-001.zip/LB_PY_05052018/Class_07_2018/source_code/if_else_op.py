'''
a=int(input("Enter the first value"))
b=int(input("Enter the second value"))
#(a%2)==0


if(a>b):
    print("inside block1")
    print(a,"is bigger")
else:
    print("inside block2")
    print(b,"is bigger")
'''
string="Naman"

if(string==string[::-1]):
    print("Palindrome")
else:
    print("not a Palindrome")