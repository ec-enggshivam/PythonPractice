
x=2
y=3

print(x+y)

x=5
y=3.5

print(x+y)

x=3+4j
y=2+6j

print(x+y)

print(x*y)
(3+4j)*(2+6j)
6+18j+8j+24(j**2)
6+18j+8j-24
-18+26j
