import sys

print("inside a module file")
print(sys.argv)

print(True)
print(False)


print(bin(True))
print(bin(False))

var=1
var+=1
print(var)