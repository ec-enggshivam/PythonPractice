
var=int(input("Enter a value"))
if(var>0):
    print(var,"is positive number and abs value is",var  )
    print("++++++++")
print("******")

if(var==0):
    print(" value of zero")
    print("00000000000")
print("^^^^^^^^^^^^")

if(var<0):
    print(var, "is negative number and abs value is", -1*(var))
    print('-------------')
print("@@@@@@@@@@")
