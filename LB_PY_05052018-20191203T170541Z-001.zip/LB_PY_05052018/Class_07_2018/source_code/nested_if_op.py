val=11
gender="female"

if(val>=0 and val<13):
    print(" Hello")
    if(gender=='male'):
        print(" Boy Child")
    else:
        print("Girl Child")
elif(val>=13 and val<17):
    if (gender == 'male'):
        print(" Boy Teen")
    else:
        print("Girl Teen")