

var=1
sum=0

while var<=10: #true
    print(var,end=' ')
    sum=sum+var
    var = var + 1
else: #opt
    print("")
    print("completed")

print ("Sum of first 10 natural number is",sum)