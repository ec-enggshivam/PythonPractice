

x=5
y=6

print("value of x is",x)
print("value of y is",y)
'''
print("Mul of", x, " and ",y,"is",x*y)

print(x>=y)
print(x==y)
print(x!=y)

print(x**y) #(4*4*4) bmf;blmflmbflmb
print(x/y) #10/3
print(x//y) #10//3 (9//3) 1
print(x%y) #4%3
'''
print(x,bin(x))

#print(y,bin(y))



#print(x|y, bin(x|y))

#print(x^y,bin(x^y))



#print (x&y,bin(x&y))
print(~x,bin(~x))
'''
print(x>>1, bin(x>>1))

print(x//2)
print(x<<1, bin(x<<1))

0b101
0b1010
0b0111111111
0*(2**(n-1))

1*(2**3)+0*(2**2)+1*(2**1)+0*(2**0)

8+0+2+0



'''





