#import cmath
import random
#from cmath import sqrt

var=random.randrange(100)

#print(cmath.sqrt(-1))
#print(sqrt(-1))
#print(cmath.sqrt(4)) #2
#print(sqrt(4))

