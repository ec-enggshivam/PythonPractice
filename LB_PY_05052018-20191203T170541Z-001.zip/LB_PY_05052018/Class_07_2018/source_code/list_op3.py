

l=[1,2,3,4,5,6]

var=False

for i in range(7):
    if(i==7):
        var=True
if(var):
    print("Exits")
else:
    print("Does not exits")


print("l is",l)
'''
L=[x for x in range(1,31) if(x%3==0) ]
print("L is ",L)


L1=[]

for i in range(1,31):
    if(i%3):
        L1.append(i)
print("L1 is",L1)
'''