
var=int(input("Enter a value"))
if(var>0):
    print(var,"is positive number and abs value is",var  )
    print("++++++++")
    print("******")
elif(var==0):
    print(" value of zero")
    print("00000000000")
#print("^^^^^^^^^^^^")
else:
    print(var, "is negative number and abs value is", -1*(var))
    print('-------------')
#print("@@@@@@@@@@")

val=11
gender="male"

if(val>=0 and val<13):
    if(gender=='male'):
        print(" Boy Child")
    else:
        print("Girl Child")
elif(val>=13 and val<17)
    print("")