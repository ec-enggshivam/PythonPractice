'''
print("*******")
print("   *  ")
print("   *  ")
print("   *  ")
print("   *  ")


var1="*******"
var2="   *  "

print(var1)
print(var2)
print(var2)
print(var2)
print(var2)
'''
var=5
print(var,bin(var))
var1=~var
print(var1,bin(var1))

var2=~var1
#-1*(var1+1)
#-1*(-6+1)
#-1*(-5)
#5
print(var2,bin(var2))



