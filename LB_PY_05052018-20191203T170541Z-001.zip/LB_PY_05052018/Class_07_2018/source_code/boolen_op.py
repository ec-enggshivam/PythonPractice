'''
x=10
y=5
print(x>=y)

print( x >= y )
'''
'''
print(bool(0))
print(bool(10))
print(bool(-1))
print(int(True))
print(int(False))
'''
var=print("Enter any data")
print(var)
print(type(var))

val=input()
print(val)
print(type(val))