
'''
a=-1
b=-False
c= a and b
print(c)
print(bin(c))

a=True
b=-False
c= a or b
print(c)
print(bin(c))

a=False
b= not a
print(b)

a=5
b=6
print(bin(a))
print(bin(b))
print(bin(a & b))
print(a & b)
print(a and b)
'''

x = 2
y = (x>1 or x<100) # False and True
print(y)
print(x)


