import random

while True:
    var=random.randrange(1,7)
    print(var)
    val=input("You want to continue.Press Y/y")
    if(val!='Y' and val!='y'):
        break






