from random import *

print("Inside the random")
var=randint(1,6)
print(var)
var=randrange(100,200)