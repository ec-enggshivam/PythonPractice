'''
l1=[2,3,4,5,1]
l1.sort(reverse=False)
print("Sorted l1",l1)

l=['Gaurav','Abhishek','Rahul','Krishna']

print(l)

l.sort()
print("Sorted l1",l)

'''
#L=[['Abhishek', 10], ['Gaurav', 11], ('Rahul', 8), ('Krishna', 9)]
L=[('Abhishek', 10), ('Gaurav', 11,), ('Rahul', 8), ('Krishna', 9)]

print(L)

sort_list = lambda val: val[1]

L.sort(key=sort_list,reverse=False)
print("After sort",L)

