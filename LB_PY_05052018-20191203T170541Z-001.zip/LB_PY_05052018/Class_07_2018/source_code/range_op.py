

#range(10)
#range(5,10)
#range(10,100,10)

#in
#not in


#for i in range(10):
#    print(i)
'''
for i in range(5,10):
    print(i)

l=[]
print(l)
for i in range(10):
    l.append(i)
print(l)

'''

l=list(range(10))
print(l)

for i in range(10,100,10):
    print(i,end=' ')

