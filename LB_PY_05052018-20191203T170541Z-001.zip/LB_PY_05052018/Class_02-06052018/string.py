


var5 ="""  hello am new to python string format 
    
      now I am attending the python classs. I will
   learn it soon"""

print(var5)
# Bellow line i am doing addition of two numbers
var=1+2
print(var)

"""  i am writing  multiline comment
He Said , "I wont't go there"""
var=1+3
print(var)