

print("hello",end=" ")

print("one","two","three","four",sep="|")

print("five","six")

print ("seven")

