import os



print("hello")
var=True

print (var)


var9=9
print (var9)

abvAXY9=9
_var=0

var=0
print(abvAXY9)

print(dir())
print(__name__)



