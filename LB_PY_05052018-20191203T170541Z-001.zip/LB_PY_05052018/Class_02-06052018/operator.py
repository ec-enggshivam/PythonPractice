


var2=100

#100/2
print(bin(var2))
var3=var2>>1
print(var3)


print(1)
var=1



