
var1=1
var2="1"
var3=1.0
var4=True
var5=False

print ("var5 is of type",type(var5))
'''
var="1024"
print (type(var))
print(var)
var=int(var)
print(type(var))
print(var)
var=str(var)
print(var)
print (type(var))
'''

var=int(input("Enter a number"))
print(var)
print(bin(var))
