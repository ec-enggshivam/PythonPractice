
var=input("Enter a number")
#print(var)
#print(type(var))
var1=int(var)
#print (var1)
#print(type(var1))

var=input("Enter a second number")
#print (var)
#print(type(var))
var2=int(var)

var3=var1+var2
#print(var3)
print("Sum of ",var1, "and",var2 ,"is",var3)

print (var1,"square is ",var1*var1)
print (var2,"square is ",var2*var2)




