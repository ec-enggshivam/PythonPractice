

print("hello world ")

print('I am  writing my first python code....')

if (True):
    print("Inside the True")

var1="5"
print (var1)

print (type(var1))

print

var2='6'

var3=var1+var2

print(var3)

